# -*- coding: utf-8 -*-
"""
    ResolveURL Plugin - StreamSilk (2025 - Headers completos)
"""

import re
from six.moves import urllib_parse
from resolveurl.lib import helpers, jsunhunt
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError


class StreamSilkResolver(ResolveUrl):
    name = 'StreamSilk'
    domains = ['streamsilk.com', 'ssilk.net']
    pattern = r'(?://|\.)(streamsilk\.com|ssilk\.net)/(?:d|p|v)/([0-9a-zA-Z$:/.]+)'

    def get_media_url(self, host, media_id):
        if '$$' in media_id:
            media_id, referer = media_id.split('$$')
            referer = urllib_parse.urljoin(referer, '/')
        else:
            referer = f'https://{host}/'

        web_url = self.get_url(host, media_id)

        headers = {
            'User-Agent': common.RAND_UA,
            'Referer': referer,
            'Origin': f'https://{host}',
            'Accept': '*/*',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin'
        }

        html = self.net.http_GET(web_url, headers=headers).content

        if jsunhunt.detect(html):
            html = jsunhunt.unhunt(html)

        match = re.search(r'urlPlay\s*=\s*"([^"]+)', html)
        if not match:
            raise ResolverError('StreamSilk: urlPlay não encontrado')

        stream_url = match.group(1).strip()

        # Headers finais para o .m3u8/.mp4 (obrigatório em 2025)
        final_headers = headers.copy()
        final_headers.update({
            'Referer': web_url,
            'Origin': f'https://{host}'
        })

        return stream_url + helpers.append_headers(final_headers)

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/p/{media_id}')