# -*- coding: utf-8 -*-
# START ADDON
from lib import addon
addon.spartan()