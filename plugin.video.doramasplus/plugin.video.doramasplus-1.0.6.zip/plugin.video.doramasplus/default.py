# -*- coding: utf-8 -*-
import sys
import os
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
from urllib.parse import quote, unquote, quote_plus, unquote_plus, urlencode
import time
import requests
from doramas import DoramasOnline

plugin = sys.argv[0]
handle = int(sys.argv[1])

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
home = xbmcvfs.translatePath(addon.getAddonInfo('path'))
fanart_default = os.path.join(home, 'fanart.jpg')
dontate_qr = os.path.join(home, 'resources', 'pix', 'qrcode-pix.png')
search_icon = os.path.join(home, 'resources', 'images', 'search.jpg')
next_icon = os.path.join(home, 'resources', 'images', 'next.jpg')
donate_icon = os.path.join(home, 'resources', 'images', 'donate.jpg')
doramas_leg_icon = os.path.join(home, 'resources', 'images', 'doramas leg.jpg')
doramas_dub_icon = os.path.join(home, 'resources', 'images', 'doramas dub.jpg')
dialog = xbmcgui.Dialog()

# Instância do scraper
scraper = DoramasOnline('https://doramasonline.org')


def route(f):
    action_f = f.__name__
    params_dict = {}
    param_string = sys.argv[2]
    if param_string:
        split_commands = param_string[param_string.find('?') + 1:].split('&')
        for command in split_commands:
            if len(command) > 0:
                if "=" in command:
                    split_command = command.split('=')
                    key = split_command[0]
                    value = split_command[1]
                    try:
                        key = unquote_plus(key)
                    except:
                        pass
                    try:
                        value = unquote_plus(value)
                    except:
                        pass
                    params_dict[key] = value
                else:
                    params_dict[command] = ""
    action = params_dict.get('action')
    if action is None and action_f == 'main':
        f(params_dict)
    elif action == action_f:
        f(params_dict)


def get_url(params):
    if params:
        url = '%s?%s' % (plugin, urlencode(params))
    else:
        url = ''
    return url


def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
    if iconimage == '':
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, iconimage, time, sound=sound)


def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = keyboard.getText()
    return search_string


def search():
    vq = get_search_string(heading='Digite a pesquisa', message="")
    if not vq:
        return False
    return vq


def get_kversion():
    full_version_info = xbmc.getInfoLabel('System.BuildVersion')
    baseversion = full_version_info.split(".")
    intbase = int(baseversion[0])
    return intbase


def item(params, folder=True):
    u = get_url(params)
    if not u:
        u = ''
    name = params.get("name", "Unknown")
    iconimage = params.get("iconimage", '')
    fanart = params.get("fanart", fanart_default)
    description = params.get("description", '')
    playable = params.get("playable")
    
    liz = xbmcgui.ListItem(name)
    liz.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
    
    if playable and playable == 'true':
        liz.setProperty('IsPlayable', 'true')
    
    if get_kversion() > 19:
        info = liz.getVideoInfoTag()
        info.setTitle(name)
        info.setMediaType('video')
        info.setPlot(description)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
    
    ok = xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=liz, isFolder=folder)
    return ok


def SetView(name):
    if name == 'List':
        try:
            xbmc.executebuiltin('Container.SetViewMode(50)')
        except:
            pass
    elif name == 'WideList':
        try:
            xbmc.executebuiltin('Container.SetViewMode(55)')
        except:
            pass


@route
def main(params):
    xbmcplugin.setContent(handle, 'tvshows')
    item({'name': 'PESQUISAR DORAMA', 'action': 'doramassearch', 'iconimage': search_icon, 'description': '[B]Pesquise doramas pelo nome[/B]'}, folder=True)
    item({'name': 'DORAMAS DUBLADOS', 'action': 'doramas_dublados', 'iconimage': doramas_dub_icon, 'description': '[B] Assista os melhores doramas[CR] dublados em português[/B]'}, folder=True)
    item({'name': 'DORAMAS LEGENDADOS', 'action': 'doramas_legendados', 'iconimage': doramas_leg_icon, 'description': '[B] Assista os melhores  doramas[CR] legendados em português[/B]'}, folder=True)
    item({'name': 'DOAÇÃO VIA PIX QR CODE', 'action': 'donate', 'iconimage': donate_icon, 'description': '[B]Ajude a manter este addon ativo[/B]'}, folder=True)
    xbmcplugin.endOfDirectory(handle)
    SetView('WideList')


@route
def doramassearch(params):
    s = search()
    if s:
        itens = scraper.search_doramas(s)
        if itens:
            xbmcplugin.setContent(handle, 'tvshows')
            for title, href, img, _, _ in itens:
                item({
                    'name': title,
                    'action': 'episodios',
                    'iconimage': img,
                    'url': href
                }, folder=True)
            xbmcplugin.endOfDirectory(handle)
            SetView('WideList')
        else:
            infoDialog('Nenhum resultado encontrado', iconimage='INFO')


@route
def doramas_dublados(params):
    page = int(params.get('page', '1'))
    itens, next_page = scraper.scraper_dublados(page=page)
    
    if itens:
        xbmcplugin.setContent(handle, 'tvshows')
        for title, href, img, _, _ in itens:
            item({
                'name': title,
                'action': 'episodios',
                'iconimage': img,
                'url': href,
                'prioridade': 'DUB'
            }, folder=True)
        
        if next_page:
            item({
                'name': f'Página {next_page}',
                'action': 'doramas_dublados',
                'iconimage': next_icon,
                'page': str(next_page)
            }, folder=True)
        
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')


@route
def doramas_legendados(params):
    page = int(params.get('page', '1'))
    itens, next_page = scraper.scraper_legendados(page=page)
    
    if itens:
        xbmcplugin.setContent(handle, 'tvshows')
        for title, href, img, _, _ in itens:
            item({
                'name': title,
                'action': 'episodios',
                'iconimage': img,
                'url': href,
                'prioridade': 'LEG'
            }, folder=True)
        
        if next_page:
            item({
                'name': f'Página {next_page}',
                'action': 'doramas_legendados',
                'iconimage': next_icon,
                'page': str(next_page)
            }, folder=True)
        
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')


@route
def episodios(params):
    url = params.get("url", "")
    prioridade = params.get("prioridade", "")
    name = params.get("name", "")
    iconimage = params.get("iconimage", "")
    
    if not url:
        return
    
    # Verifica se é um filme
    if '/filmes/' in url:
        item({
            'name': name,
            'action': 'opcoes',
            'iconimage': iconimage,
            'url': url,
            'prioridade': prioridade,
            'playable': 'true'
        }, folder=False)
        xbmcplugin.endOfDirectory(handle)
        return
    
    # Verifica se tem players diretos na página (sem lista de episódios)
    try:
        r = scraper.soup(requests.get(url, headers=scraper.headers, timeout=10).text)
        if r.find('ul', {'id': 'playeroptionsul'}):
            # Tem players direto, é um filme ou episódio único
            item({
                'name': name,
                'action': 'opcoes',
                'iconimage': iconimage,
                'url': url,
                'prioridade': prioridade,
                'playable': 'true'
            }, folder=False)
            xbmcplugin.endOfDirectory(handle)
            return
    except:
        pass
    
    # Lista episódios normalmente
    lista_episodios = scraper.scraper_episodios(url)
    if lista_episodios:
        xbmcplugin.setContent(handle, 'tvshows')
        for title, link, img, _ in lista_episodios:
            item({
                'name': title,
                'action': 'opcoes',
                'iconimage': img,
                'url': link,
                'prioridade': prioridade,
                'playable': 'true'
            }, folder=False)
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')
    else:
        infoDialog('Nenhum episódio encontrado', iconimage='INFO')


def select_op(name, items):
    op = dialog.select(name, items)
    return op


@route
def opcoes(params):
    name = params.get("name", "Doramas")
    url = params.get("url", "")
    iconimage = params.get("iconimage", "")
    description = params.get("description", "")
    prioridade = params.get("prioridade", "").upper()
    
    if url:
        op = scraper.scraper_players(url)
        
        if not op:
            infoDialog('NENHUMA OPÇÃO DE PLAYER DISPONÍVEL', iconimage='ERROR')
            return
        
        # Filtra players pela prioridade (DUB ou LEG)
        if prioridade:
            op_filtradas = [(nome, link) for nome, link in op if prioridade in nome.upper()]
            
            # Se não encontrou players com a prioridade, avisa o usuário
            if not op_filtradas:
                infoDialog(f'Nenhum player {prioridade} encontrado!', iconimage='WARNING')
                return
            
            op = op_filtradas
        
        if op:
            items_options = [option for option, link in op]
            try:
                op2 = select_op(name='SELECIONE UMA OPÇÃO ABAIXO:', items=items_options)
            except:
                op2 = 0
            
            if op2 >= 0:
                infoDialog('AGUARDE...', iconimage='INFO')
                page = op[op2][1]
                
                # Tenta resolver o link
                try:
                    import resolveurl
                except:
                    xbmc.executebuiltin("UpdateLocalAddons()")
                    xbmc.executebuiltin("UpdateAddonRepos()")
                    xbmc.executebuiltin('InstallAddon(script.module.resolveurl)')
                    xbmc.executebuiltin('SendClick(11)')
                    time.sleep(7)
                
                try:
                    import resolveurl
                    if resolveurl.HostedMediaFile(page):
                        stream = resolveurl.resolve(page)
                    else:
                        stream = ''
                except:
                    stream = ''
                
                if not stream:
                    time.sleep(5)
                    try:
                        import resolveurl
                        if resolveurl.HostedMediaFile(page):
                            stream = resolveurl.resolve(page)
                        else:
                            stream = ''
                    except:
                        stream = ''
                
                if stream:
                    liz = xbmcgui.ListItem(name)
                    liz.setPath(stream)
                    liz.setArt({"fanart": "", "icon": iconimage, "thumb": iconimage})
                    
                    if get_kversion() > 19:
                        info = liz.getVideoInfoTag()
                        info.setTitle(name)
                        info.setMediaType('video')
                        info.setPlot(description)
                    else:
                        liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description})
                    
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
                else:
                    infoDialog('STREAM INDISPONÍVEL, TENTE OUTRO PLAYER', iconimage='INFO')
        else:
            infoDialog('NENHUMA OPÇÃO DE PLAYER DISPONÍVEL', iconimage='INFO')


class Donate(xbmcgui.WindowDialog):
    def __init__(self):
        self.image = xbmcgui.ControlImage(440, 145, 400, 400, dontate_qr)
        self.text = xbmcgui.ControlLabel(
            x=150, y=570, width=1100, height=25,
            label='[B]SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX ACIMA E MANTENHA ESSE SERVIÇO ATIVO[/B]',
            textColor='white'
        )
        self.text2 = xbmcgui.ControlLabel(
            x=495, y=600, width=1000, height=25,
            label='[B]PRESSIONE VOLTAR PARA SAIR[/B]',
            textColor='white'
        )
        self.addControl(self.image)
        self.addControl(self.text)
        self.addControl(self.text2)


@route
def donate(params):
    dialog_donate = Donate()
    dialog_donate.doModal()