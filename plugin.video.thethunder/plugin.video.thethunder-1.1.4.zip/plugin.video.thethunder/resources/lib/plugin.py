# -*- coding: utf-8 -*-
import sys
import six
import os
try:
    from urllib.parse import urlparse, parse_qs, unquote_plus, urlencode #python 3
except ImportError:    
    from urlparse import urlparse, parse_qs #python 2
    from urllib import unquote_plus, urlencode
from resources.lib import menus, providers, control, update, subtitles, language as lang
from kodi_six import xbmc, xbmcvfs, xbmcgui, xbmcplugin, xbmcaddon
  

def run():
    args = parse_qs(sys.argv[2][1:])
    action = args.get("action")
    name = args.get("name")
    url = args.get("url")
    iconimage = args.get("iconimage")
    fanart = args.get("fanart")
    description = args.get("description")
    codec = args.get("codec")
    playable = args.get("playable")
    duration = args.get("duration")
    originaltitle = args.get("originaltitle")
    imdbnumber = args.get("imdbnumber")
    aired = args.get("aired")
    genre = args.get("genre")
    season = args.get("season")
    episode = args.get("episode")
    search1 = args.get("search1")
    search2 = args.get("search2")
    search3 = args.get("search3")
    video_id = args.get("video_id")
    video_title = args.get("video_title")
    subtitle = args.get("subtitle")
    year = args.get("year")
    page = args.get("page")
    page_url = args.get("page_url")
    addon_id = args.get("addon_id")
    searchstring = args.get("searchstring")
    preferredlanguage = args.get("preferredlanguage")
    sub_download = args.get("sub_download")
    if preferredlanguage:
        default_subtitle = preferredlanguage[0]
    else:
        default_subtitle = 'unknow'
    if sub_download:
        sub_download = sub_download[0]
    else:
        sub_download = False        
    if name:
        name = name[0]
    else:
        name = 'Unknow'
    if url:
        url = url[0]
    else:
        url = ''
    if iconimage:
        iconimage = iconimage[0]
    else:
        iconimage = ''
    if fanart:
        fanart = fanart[0]
    else:
        fanart = ''
    if description:
        description = description[0]
    else:
        description = ''
    if codec:
        codec = codec[0]
    else:
        codec = 'false'
    if playable:
        playable = playable[0]
    else:
        playable = 'false'
    if duration:
        duration = duration[0]
    else:
        duration = 'false'
    if originaltitle:
        originaltitle = originaltitle[0]
    else:
        originaltitle = 'false'
    if imdbnumber:
        imdbnumber = imdbnumber[0]
    else:
        imdbnumber = 'false'
    if aired:
        aired = aired[0]
    else:
        aired = 'false'
    if genre:
        genre = genre[0]
    else:
        genre = 'false'
    if season:
        season = season[0]
    else:
        season = 'false'
    if episode:
        episode = episode[0]
    else:
        episode = 'false'
    if search1:
        search1 = search1[0]
    else:
        search1 = 'false'
    if search2:
        search2 = search2[0]
    else:
        search2 = 'false'
    if search3:
        search3 = search3[0]
    else:
        search3 = 'false'        
    if video_id:
        video_id = video_id[0]
    else:
        video_id = ''
    if video_title:
        video_title = video_title[0]
    else:
        video_title = ''
    if subtitle:
        subtitle = subtitle[0]
    else:
        subtitle = ''
    if year:
        year = year[0]
    else:
        year = '0'
    if page:        
        page = page[0]
    else:
        page = 1
    if addon_id:
        addon_id = addon_id[0]
    else:
        addon_id = ''
    if action == None:
        update.auto_update()
        menus.home()
    elif 'search' in action:
        subtitles.search_subtitle(default_subtitle)
    elif 'manualsearch' in action:
        if searchstring:
            searchstring = searchstring[0]
            subtitles.search_subtitle(default_subtitle,manualsearch=searchstring)
    elif 'download' in action:
        if sub_download:
            subtitles.download(sub_download)
    elif 'play' in action:
        update.auto_update()
        providers.play(video_title,url,iconimage,fanart,description,genre,imdbnumber,originaltitle,year,season,episode,playable,subtitle)
    elif 'play2' in action:
        update.auto_update()
        control.play(name,url,iconimage,fanart,description,playable)
    elif 'play3' in action:
        update.auto_update()
        providers.play3(video_title,url,iconimage,fanart,description,genre,imdbnumber,originaltitle,year,season,episode,playable,subtitle)
    elif 'movies' in action:
        update.auto_update()
        menus.movies()
    elif 'premiere_movies' in action:
        update.auto_update()
        menus.pagination_movies_premiere(page)
    elif 'trending_movies' in action:
        update.auto_update()
        menus.pagination_movies_trending(page)
    elif 'search_movies' in action:
        update.auto_update()
        if search3 == 'false':
            sch = control.search()
        else:
            sch = search3
        if not sch == False and not sch == 'false':
            menus.pagination_search_movies(sch,page)
    elif 'tv_shows' in action:
        update.auto_update()
        menus.tv_shows()
    elif 'premiere_tv_shows' in action:
        update.auto_update()
        menus.pagination_tv_shows_premiere(page)
    elif 'season_tvshow' in action:
        update.auto_update()
        menus.season_tvshow(video_title,originaltitle,year,video_id)
    elif 'episode_tvshow' in action:
        update.auto_update()
        menus.episode_tvshow(video_title,originaltitle,genre,imdbnumber,year,duration,video_id,season,iconimage,fanart)
    elif 'trending_tv_shows' in action:
        update.auto_update()
        menus.pagination_tv_shows_trending(page)
    elif 'new_episodes' in action:
        update.auto_update()
        menus.new_episodes()
    elif 'search_tv_shows' in action:
        update.auto_update()
        if search3 == 'false':
            sch = control.search()
        else:
            sch = search3
        if not sch == False and not sch == 'false':
            menus.pagination_search_tv_shows(sch,page)
    elif 'animes' in action:
        update.auto_update()
        menus.animes()
    elif 'animes_list' in action:
        update.auto_update()
        menus.animes_list(url)
    elif 'animes_episodes' in action:
        update.auto_update()
        menus.animes_episodes(video_title,url,fanart)
    elif 'search_animes' in action:
        update.auto_update()
        sch = control.search()
        if sch:
            menus.animes_search(sch)
    elif 'provider' in action:
        update.auto_update()
        providers.servers_list(name,iconimage,fanart,description,genre,imdbnumber,search1,search2,originaltitle,video_title,year,season,episode)
    elif 'provider_animes' in action:
        update.auto_update()
        providers.servers_list2(video_title,iconimage,fanart,description,search1,season,episode)
    elif 'live_tv' in action:
        update.auto_update()
        menus.live_tv()
    elif 'live_channels_brazil' in action:
        update.auto_update()
        menus.pagination_live_channels_brazil(page)
    elif 'live_channels_brazil2' in action:
        update.auto_update()
        menus.live_channels_brazil2()       
    elif 'live_channels_usa' in action:
        update.auto_update()
        menus.pagination_live_channels_usa(page)
    elif 'open_live_channels' in action:
        update.auto_update()
        menus.open_live_channels(url)
    elif 'playlist' in action:
        update.auto_update()
        menus.playlist(url)
    elif 'playlist2' in action:
        update.auto_update()
        menus.playlist2(name,url)
    elif 'tools' in action:
        update.auto_update()
        menus.tools()
    elif 'link_tester' in action:
        link = control.enter_url()
        if link:
            link = providers.tester(link)
            if link:
                control.play('Link Tester',link,'','','','false')
    elif 'resolveurl' in action:
        if six.PY3:
            resolveurl = xbmcvfs.translatePath('special://home/addons/script.module.resolveurl')
        else:
            resolveurl = xbmc.translatePath('special://home/addons/script.module.resolveurl')
        if os.path.exists(resolveurl)==True:
            xbmcaddon.Addon('script.module.resolveurl').openSettings()
        else:
            control.infoDialog('Does not exist',iconimage='WARNING')
    elif 'update' in action:
        update.update()
    elif 'install' in action:
        update.install(addon_id,url)
    elif 'donate' in action:
        dg = control.Donate()
        dg.doModal()