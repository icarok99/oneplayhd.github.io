# -*- coding: utf-8 -*-
import six
from kodi_six import xbmc, xbmcvfs, xbmcgui, xbmcplugin, xbmcaddon
from resources.lib import control, navigator, language as lang
try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
except ImportError:    
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
import re
import sys
import os

plugin = sys.argv[0]
handle = int(sys.argv[1])
addon_data = control.profile
temp = os.path.join(addon_data, 'temp')

try:
    os.mkdir(addon_data)
except:
    pass
try:
    os.mkdir(temp)
except:
    pass
    
def unzip(path, dest, format):
    path = quote_plus(path)
    root = format + '://' + path + '/'
    dirs, files = xbmcvfs.listdir(root)
    if dirs:
        unzip_recursive(root, dirs, dest)
    for file in files:
        if six.PY3:
            unzip_file(os.path.join(root, file), os.path.join(dest, file))
        else:
            unzip_file(os.path.join(root, file.decode('utf-8')), os.path.join(dest, file.decode('utf-8')))

def unzip_recursive(path, dirs, dest):
    for directory in dirs:
        if six.PY3:
            dirs_dir = os.path.join(path, directory)
            dest_dir = os.path.join(dest, directory)
        else:
            dirs_dir = os.path.join(path, directory.decode('utf-8'))
            dest_dir = os.path.join(dest, directory.decode('utf-8'))            
        xbmcvfs.mkdir(dest_dir)

        dirs2, files = xbmcvfs.listdir(dirs_dir)

        if dirs2:
            unzip_recursive(dirs_dir, dirs2, dest_dir)
        for file in files:
            if six.PY3:
                unzip_file(os.path.join(dirs_dir, file), os.path.join(dest_dir, file))
            else:
                unzip_file(os.path.join(dirs_dir, file.decode('utf-8')), os.path.join(dest_dir, file.decode('utf-8')))

def unzip_file(path, dest):
    ''' Unzip specific file. Path should start with zip://
    '''
    xbmcvfs.copy(path, dest) 


def get_url(params):
    url = '%s?%s'%(plugin, urlencode(params))
    return url

def subitem(params):
    url = get_url(params)
    language = params.get("language")
    subname = params.get("subname") 
    rating = params.get("rating")
    flag = params.get("flag")
    sub = params.get("sub")
    if language and subname and rating and flag:
        if six.PY3:
            li=xbmcgui.ListItem(label=language,label2=subname)
            li.setArt({"icon": rating, "thumb": flag})
        else:
            li = xbmcgui.ListItem(label=language,label2=subname, iconImage=rating, thumbnailImage=flag)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    elif sub:
        li=xbmcgui.ListItem(label2=os.path.basename(sub))
        xbmcplugin.addDirectoryItem(handle=handle, url=sub, listitem=li, isFolder=False)        
    

def originaltitle_imdb(imdb):
    url = 'https://www.imdb.com/title/%s/reference'%imdb
    data = navigator.open_url2(url)
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(data, 'html.parser')
        originaltitle = soup.find('meta', {'property': 'og:title'}).get('content')
        try:
            originaltitle = originaltitle.split(' (')[0]
        except:
            pass
    except:
        originaltitle = False
    return originaltitle
    

def detect_info():
    tag = xbmc.Player().getVideoInfoTag()
    imdb = tag.getIMDBNumber()
    if imdb !='-1' and imdb !=False and imdb !=-1 and imdb !=None and imdb !='':
        originaltitle = originaltitle_imdb(imdb)
        search = originaltitle
    else:
        search = False
        control.infoDialog('Without imdb', iconimage='INFO')
    try:
        season = tag.getSeason()
    except:
        season = False
    try:
        episode = tag.getEpisode()
    except:
        episode = False
    return search, season, episode


def legendei(sch):
    data = ''
    link = 'https://legendei.to/?s=%s'%sch
    data1 = navigator.open_url(link)
    data += data1
    next = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data1)
    if next:
        url = next[0]
        data2 = navigator.open_url(url)
        data += data2
        next2 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)
        if next2:
            url = next2[0]
            data3 = navigator.open_url(url)
            data += data3
            next3 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data3)
            if next3:
                url = next3[0]
                data4 = navigator.open_url(url)
                data += data4
                next4 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                if next4:
                    url = next4[0]
                    data5 = navigator.open_url(url)
                    data += data5
                    next5 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data5)
                    if next5:
                        url = next5[0]
                        data6 = navigator.open_url(url)
                        data += data6
                        next6 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data6)
                        if next6:
                            url = next6[0]
                            data7 = navigator.open_url(url)
                            data += data7
                            next7 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data7)
                            if next7:
                                url = next7[0]
                                data8 = navigator.open_url(url)
                                data += data8
                                next8 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data8)
                                if next8:
                                    url = next8[0]
                                    data9 = navigator.open_url(url)
                                    data += data9
                                    next9 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data9)
                                    if next9:
                                        url = next9[0]
                                        data10 = navigator.open_url(url)
                                        data += data10
                                        next10 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data10)
                                        if next10:
                                            url = next10[0]
                                            data11 = navigator.open_url(url)
                                            data += data11
                                            next11 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data11)
                                            if next11:
                                                url = next11[0]
                                                data12 = navigator.open_url(url)
                                                data += data12
                                                next12 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data12)
                                                if next12:
                                                    url = next12[0]
                                                    data13 = navigator.open_url(url)
                                                    data += data13
                                                    next13 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data13)
                                                    if next13:
                                                        url = next13[0]
                                                        data14 = navigator.open_url(url)
                                                        data += data14
                                                        next14 = re.compile(r'<a class="nextpostslink" rel="next" href="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data14)
                                                        if next14:
                                                            url = next14[0]
                                                            data15 = navigator.open_url(url)
                                                            data += data15
    items = re.compile(r'<h3 class="simple-grid-grid-post-title"><a href="(.*?)" rel="bookmark">(.*?)</a></h3>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if items:
        for lk, name in items:
            try:
                name = name.encode('utf-8', 'ignore')
            except:
                pass
            subitem({'language': 'Portuguese (Brasil)', 'subname': name, 'rating': '5', 'flag': 'pb', 'action': 'download', 'sub_download': lk})
        xbmcplugin.endOfDirectory(handle)

def subtitle_clear():
    for r, d, f in os.walk(temp):
        for file in f:
            if file.endswith(".srt"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
            if file.endswith(".url"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass 
            if file.endswith(".rar"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
            if file.endswith(".zip"):
                try:
                    os.remove(os.path.join(r, file))
                except:
                    pass
    for name in os.listdir(temp):
        try:
            os.rmdir(os.path.join(temp, name))
        except:
            pass


def subs_site(lang,manualsearch=False):
    if lang == 'pt':
        if manualsearch:
            sch = quote(manualsearch)
            legendei(sch)
        else:
            search, season, episode = detect_info()
            if season !='-1' and season !=False and season !=-1:
                season = season
            else:
                season = False
            if episode !='-1' and episode !=False and episode !=-1:
                episode = episode
            else:
                episode = False
            if search and season:
                if int(season) < 10:
                    sdesc = '0%s'%str(season)
                else:
                    sdesc = str(season)            
                sch = '%s S%s'%(search,sdesc)
                sch = quote(sch)
            elif search:
                sch = quote(search)
            else:
                sch = False            
            if sch:
                legendei(sch)
            else:
                pass

def search_subtitle(default_subtitle,manualsearch=False):
    subtitle_clear()
    if six.PY3:
        try:
            xbmc.executebuiltin('InstallAddon(vfs.rar)', wait=True)
        except:
            pass    
    else:
        try:
            xbmc.executebuiltin('InstallAddon(vfs.libarchive)', wait=True)
        except:
            pass
    if 'Portuguese' in default_subtitle:
        lang = 'pt'
    else:
        lang = 'pt'
    if manualsearch:
        subs_site(lang,manualsearch)
    else:
        subs_site(lang)

def list_subtitle():
    from resources.lib import extract
    names = []
    links = []
    for r, d, f in os.walk(temp):
        for file in f:
            if file.endswith(".rar"):
                try:
                    unzip(os.path.join(r, file),temp,'rar')
                except:
                    pass
    for r, d, f in os.walk(temp):
        for file in f:
            if file.endswith(".zip"):
                try:
                    extract.all(os.path.join(r, file),temp)
                except:
                    pass   
    for r, d, f in os.walk(temp):
        for file in f:              
            if file.endswith(".srt"):
                filename = file
                link = os.path.join(r, file)
                names.append(filename)
                links.append(link) 
    if names and links:
        index = xbmcgui.Dialog().select('Select a subtitle', names)
        if index >=0:
            link = links[index]
            set_subtitle(link)


def download(url):
    subtitle_clear()
    data = navigator.open_url(url)
    link1 = re.compile(r'<a class="buttondown" href="(.*?)" rel="nofollow">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    link2 = re.compile('<a href="(.*?)" class="rcw-button-0 rcw-medium orange ">Download Legenda</a>').findall(data)
    if link1:
        link = link1[0]
    elif link2:
        link = url + link2[0]
    else:
        link = False    
    if link:
        link_zip = link    
        special_packages = 'special://home/addons/packages'
        if six.PY3:
            packages = xbmcvfs.translatePath(special_packages)
        else:
            packages = xbmc.translatePath(special_packages)
        from resources.lib import downloader, extract
        filename = 'thunder_subtitle.subpack'
        dest=os.path.join(packages, filename)            
        try:
            navigator.download_url(link_zip, dest)
            zip_file = dest
            extract_folder = temp
            try:
                unzip(zip_file,extract_folder,'rar')
            except:
                pass
            try:
                extract.all(zip_file,extract_folder)
            except:
                pass
            try:
                os.remove(zip_file)
            except:
                pass
        except:
            pass
        try:
            os.remove(dest)
        except:
            pass            
        list_subtitle()       
    
def set_subtitle(sub):
    subitem({'sub': sub})
    xbmcplugin.endOfDirectory(handle)